package com.example.filmin.controller;

import com.example.filmin.dto.AdminLoginDTO;
import com.example.filmin.dto.PlanEntity;
import com.example.filmin.dto.UserEntity;
import com.example.filmin.repository.PlanRepository;
import com.example.filmin.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    private static final String ADMIN_EMAIL = "admin@filmin.cz";

    @Autowired
    private UserService userService;

    @Autowired
    private PlanRepository planRepository;

    // --- Auth ---

    @PostMapping("/login")
    public ResponseEntity<?> adminLogin(@RequestBody AdminLoginDTO dto, HttpSession session) {
        if (!dto.getEmail().equals(ADMIN_EMAIL)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Přístup zamítnut.");
        }

        UserEntity user = userService.findByEmail(dto.getEmail());
        if (user == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Admin účet nenalezen.");
        }

        if (!userService.checkPassword(user, dto.getPassword())) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Špatné heslo.");
        }

        session.setAttribute("adminLoggedIn", true);
        return ResponseEntity.ok("Přihlášení admina úspěšné.");
    }

    @PostMapping("/logout")
    public ResponseEntity<?> adminLogout(HttpSession session) {
        session.invalidate();
        return ResponseEntity.ok("Admin odhlášen.");
    }

    @GetMapping("/session-check")
    public ResponseEntity<?> sessionCheck(HttpSession session) {
        Object admin = session.getAttribute("adminLoggedIn");
        if (admin != null && (boolean) admin) {
            return ResponseEntity.ok("Admin přihlášen.");
        }
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Admin není přihlášen.");
    }

    // --- Správa uživatelů ---

    @GetMapping("/users")
    public ResponseEntity<?> getAllUsers(HttpSession session) {
        if (!isAdmin(session)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Přístup zamítnut.");
        }

        List<Map<String, Object>> users = userService.findAllUsers().stream()
                .map(user -> {
                    Map<String, Object> map = new HashMap<>();
                    map.put("id", user.getId());
                    map.put("email", user.getEmail());
                    map.put("planId", user.getPlan().getId());
                    map.put("planNazev", user.getPlan().getNazev());
                    return map;
                })
                .toList();

        return ResponseEntity.ok(users);
    }

    @DeleteMapping("/users/{id}")
    public ResponseEntity<?> deleteUser(@PathVariable Long id, HttpSession session) {
        if (!isAdmin(session)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Přístup zamítnut.");
        }

        try {
            userService.deleteUser(id);
            return ResponseEntity.ok("Uživatel smazán.");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Uživatel nenalezen.");
        }
    }

    @PostMapping("/users/{id}/change-plan")
    public ResponseEntity<?> changeUserPlan(@PathVariable Long id, @RequestBody Map<String, Integer> body, HttpSession session) {
        if (!isAdmin(session)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Přístup zamítnut.");
        }

        int planId = body.get("planId");
        Optional<UserEntity> userOpt = userService.findUserById(id);
        Optional<PlanEntity> planOpt = planRepository.findById((long) planId);

        if (userOpt.isEmpty()) return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Uživatel nenalezen.");
        if (planOpt.isEmpty()) return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Plán nenalezen.");

        userService.changeUserPlan(id, planId);
        return ResponseEntity.ok("Plán změněn.");
    }

    // --- Helper ---

    private boolean isAdmin(HttpSession session) {
        Object admin = session.getAttribute("adminLoggedIn");
        return admin != null && (boolean) admin;
    }
}
