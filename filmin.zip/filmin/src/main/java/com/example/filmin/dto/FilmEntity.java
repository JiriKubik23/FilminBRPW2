package com.example.filmin.dto;

import jakarta.persistence.*;

@Entity
@Table(name = "films")
public class FilmEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String nazev;

    @Column(columnDefinition = "TEXT")
    private String popis;

    private String director;

    private String script;

    private String music;

    private String cinematographer;

    // název souboru obrázku, např. "dune.png"
    private String obrazek;

    public FilmEntity() {
    }

    public FilmEntity(String nazev, String popis, String director, String script,
                      String music, String cinematographer, String obrazek) {
        this.nazev = nazev;
        this.popis = popis;
        this.director = director;
        this.script = script;
        this.music = music;
        this.cinematographer = cinematographer;
        this.obrazek = obrazek;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNazev() {
        return nazev;
    }

    public void setNazev(String nazev) {
        this.nazev = nazev;
    }

    public String getPopis() {
        return popis;
    }

    public void setPopis(String popis) {
        this.popis = popis;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getScript() {
        return script;
    }

    public void setScript(String script) {
        this.script = script;
    }

    public String getMusic() {
        return music;
    }

    public void setMusic(String music) {
        this.music = music;
    }

    public String getCinematographer() {
        return cinematographer;
    }

    public void setCinematographer(String cinematographer) {
        this.cinematographer = cinematographer;
    }

    public String getObrazek() {
        return obrazek;
    }

    public void setObrazek(String obrazek) {
        this.obrazek = obrazek;
    }
}
