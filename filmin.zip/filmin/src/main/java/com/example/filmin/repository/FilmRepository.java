package com.example.filmin.repository;

import com.example.filmin.dto.FilmEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface FilmRepository extends JpaRepository<FilmEntity, Long> {
    Optional<FilmEntity> findByNazev(String nazev);
}
