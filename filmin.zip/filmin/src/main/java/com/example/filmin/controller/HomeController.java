package com.example.filmin.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * SPA fallback - všechny cesty, které neodpovídají API ani statickému souboru,
 * jsou přesměrovány na index.html, aby je mohl obsloužit React Router.
 */
@Controller
public class HomeController {

    @GetMapping(value = {
            "/",
            "/login",
            "/register",
            "/home",
            "/ucet",
            "/plany",
            "/dune2",
            "/admin",
            "/adminpanel",
            "/film/{id}"
    })
    public String forward() {
        return "forward:/index.html";
    }
}
