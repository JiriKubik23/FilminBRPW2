package com.example.filmin.controller;

import com.example.filmin.dto.FilmDTO;
import com.example.filmin.dto.FilmEntity;
import com.example.filmin.service.FilmService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(
        origins = "http://localhost:5173",
        allowCredentials = "true"
)
@RestController
@RequestMapping("/api/films")
public class FilmController {

    @Autowired
    private FilmService filmService;

    @GetMapping
    public List<FilmDTO> getAllFilms() {
        return filmService.findAllFilms()
                .stream()
                .map(this::toDTO)
                .toList();
    }

    @GetMapping("/{id}")
    public ResponseEntity<FilmDTO> getFilmById(@PathVariable Long id) {
        return filmService.findFilmById(id)
                .map(this::toDTO)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<FilmDTO> createFilm(@Valid @RequestBody FilmDTO dto) {
        FilmEntity film = new FilmEntity(
                dto.getNazev(),
                dto.getPopis(),
                dto.getDirector(),
                dto.getScript(),
                dto.getMusic(),
                dto.getCinematographer(),
                dto.getObrazek()
        );
        FilmEntity saved = filmService.createFilm(film);
        return new ResponseEntity<>(toDTO(saved), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<FilmDTO> updateFilm(@PathVariable Long id, @Valid @RequestBody FilmDTO dto) {
        try {
            FilmEntity data = new FilmEntity(
                    dto.getNazev(),
                    dto.getPopis(),
                    dto.getDirector(),
                    dto.getScript(),
                    dto.getMusic(),
                    dto.getCinematographer(),
                    dto.getObrazek()
            );
            FilmEntity updated = filmService.updateFilm(id, data);
            return ResponseEntity.ok(toDTO(updated));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteFilm(@PathVariable Long id) {
        if (filmService.findFilmById(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        filmService.deleteFilm(id);
        return ResponseEntity.ok("Film smazán.");
    }

    private FilmDTO toDTO(FilmEntity film) {
        return new FilmDTO(
                film.getId(),
                film.getNazev(),
                film.getPopis(),
                film.getDirector(),
                film.getScript(),
                film.getMusic(),
                film.getCinematographer(),
                film.getObrazek()
        );
    }
}
