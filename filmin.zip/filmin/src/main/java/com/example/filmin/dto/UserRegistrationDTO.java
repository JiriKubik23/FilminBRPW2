package com.example.filmin.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

public class UserRegistrationDTO {
    @NotBlank(message = "Heslo nesmí být prázdné")
    private String password;

    @Email(message = "Email není ve správném formátu")
    @NotBlank(message = "Email nesmí být prázdný")
    private String email;

    private Long planId;

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public Long getPlanId() { return planId; }
    public void setPlanId(Long planId) { this.planId = planId; }
}
