package com.example.filmin.service;

import com.example.filmin.dto.FilmEntity;
import com.example.filmin.repository.FilmRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FilmService {

    @Autowired
    private FilmRepository filmRepository;

    public List<FilmEntity> findAllFilms() {
        return filmRepository.findAll();
    }

    public Optional<FilmEntity> findFilmById(Long id) {
        return filmRepository.findById(id);
    }

    public FilmEntity createFilm(FilmEntity film) {
        return filmRepository.save(film);
    }

    public void deleteFilm(Long id) {
        filmRepository.deleteById(id);
    }

    public FilmEntity updateFilm(Long id, FilmEntity filmData) {
        return filmRepository.findById(id)
                .map(film -> {
                    film.setNazev(filmData.getNazev());
                    film.setPopis(filmData.getPopis());
                    film.setDirector(filmData.getDirector());
                    film.setScript(filmData.getScript());
                    film.setMusic(filmData.getMusic());
                    film.setCinematographer(filmData.getCinematographer());
                    film.setObrazek(filmData.getObrazek());
                    return filmRepository.save(film);
                })
                .orElseThrow(() -> new RuntimeException("Film nenalezen"));
    }
}
