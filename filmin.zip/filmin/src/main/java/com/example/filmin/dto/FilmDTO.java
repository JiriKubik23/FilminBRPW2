package com.example.filmin.dto;

import jakarta.validation.constraints.NotBlank;

public class FilmDTO {
    private Long id;

    @NotBlank
    private String nazev;

    private String popis;
    private String director;
    private String script;
    private String music;
    private String cinematographer;
    private String obrazek;

    public FilmDTO() {
    }

    public FilmDTO(Long id, String nazev, String popis, String director, String script,
                   String music, String cinematographer, String obrazek) {
        this.id = id;
        this.nazev = nazev;
        this.popis = popis;
        this.director = director;
        this.script = script;
        this.music = music;
        this.cinematographer = cinematographer;
        this.obrazek = obrazek;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNazev() {
        return nazev;
    }

    public void setNazev(String nazev) {
        this.nazev = nazev;
    }

    public String getPopis() {
        return popis;
    }

    public void setPopis(String popis) {
        this.popis = popis;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getScript() {
        return script;
    }

    public void setScript(String script) {
        this.script = script;
    }

    public String getMusic() {
        return music;
    }

    public void setMusic(String music) {
        this.music = music;
    }

    public String getCinematographer() {
        return cinematographer;
    }

    public void setCinematographer(String cinematographer) {
        this.cinematographer = cinematographer;
    }

    public String getObrazek() {
        return obrazek;
    }

    public void setObrazek(String obrazek) {
        this.obrazek = obrazek;
    }
}
